package test;

public class multithreadingbasic extends Thread {
	public void run() {
		System.out.println("Test multithreading");
	}
}
