package test;

public class MultithreadingExample {
	public static void main(String[] args) {
		Thread t1 = new multithreadingbasic();
		t1.start();
	}
}
