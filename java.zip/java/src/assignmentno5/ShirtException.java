package assignmentno5;

public class ShirtException extends Exception {
	private Shirt shirts[];
	
	
}
