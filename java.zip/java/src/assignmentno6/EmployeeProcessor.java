package assignmentno6;

public interface EmployeeProcessor {
	public float processEmployees(Employee employee[], String name);
}
