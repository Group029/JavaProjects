
public class to {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String sc = "Aniket i love s";
		 
	for(int i=0;i<sc.length();i++) {
		System.out.println(sc.charAt(i));
	}
} 
}